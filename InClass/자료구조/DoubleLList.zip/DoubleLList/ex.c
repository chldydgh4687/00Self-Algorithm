#include <stdio.h>
#include <stdlib.h>
#include "DoubleLList.h"

int main()
{
	DLL* new_list = NULL;
	DLN new_node;

	new_list = Create_List();
	if (new_list != NULL) {
		new_node.data = 1;
		add_data(new_list, 0, new_node);
		
		new_node.data = 2;
		add_data(new_list, 1, new_node);
		
		new_node.data = 3;
		add_data(new_list, 1, new_node);

		new_node.data = 5;
		add_data(new_list, 3, new_node);

		remove_data(new_list, 3);
		Display(new_list);

		printf("\n");
		reverse_Display(new_list);

		delete_data(new_list);
	}
	else {
		printf("new_list : �����Ҵ����\n");
		return 0;
	}
}