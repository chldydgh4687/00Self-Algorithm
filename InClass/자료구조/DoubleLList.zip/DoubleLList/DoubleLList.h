#pragma once
#ifndef __DoubleLList__
#define __DoubleLList__

typedef struct DoubleListNode {
	int data;
	struct DoubleListNode *pLink;
	struct DoubleListNode *fLink;
}DLN;

typedef struct DoubleLList {
	int currentdata;
	DLN *headernode;
}DLL;

//function

DLL* Create_List();
void Display(DLL *p);
void reverse_Display(DLL *p);
int add_data(DLL *p, int pos, DLN node);
int remove_data(DLL *p, int pos);
int delete_data(DLL *p);

#endif // !__DoubleLList__
