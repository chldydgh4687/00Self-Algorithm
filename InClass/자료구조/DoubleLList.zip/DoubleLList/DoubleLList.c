#include <stdio.h>
#include <stdlib.h>
#include "DoubleLList.h"

void Display(DLL *p) {
	DLN *data_node = NULL;
	data_node = p->headernode;
	for (int i = 0; i < p->currentdata; i++) {
		printf("[%d] = %d\n", i, data_node->data);
		data_node = data_node->pLink;
	}

	return 0;
}

DLL* Create_List() {
	DLL *new_list = (DLL*)malloc(sizeof(DLL));
	if (new_list != NULL) {
		new_list->currentdata = 0;
		return new_list;
 	}
	else {
		printf("Create_List : �Ҵ����");
		return 0;
	}
}

int add_data(DLL *p, int pos, DLN data) {
	DLN *new_data = (DLN*)malloc(sizeof(DLN));
	DLN *fnode = NULL;
	DLN *anode = NULL;
	if (new_data != NULL) {
		*new_data = data;
		if (p->currentdata == 0 && pos == 0) {
			p->headernode = new_data;
			p->headernode->fLink = NULL;
			p->headernode->pLink = NULL;
		}
		else if(p->currentdata > pos){
			anode = (p->headernode);
			for (int i = 0; i < pos; i++) {
				anode = anode->pLink;
			}
			fnode = anode->fLink;

			fnode->pLink = new_data;
			new_data->fLink = fnode;

			new_data->pLink = anode;
			anode->fLink = new_data;
		}
		else if (p->currentdata == pos) {
			fnode = (p->headernode);
			for (int i = 0; i < pos-1; i++) {
				fnode = fnode->pLink;
			}
			new_data->fLink = fnode;
			fnode->pLink = new_data;
			new_data->pLink = NULL;
		}
		else {
			printf("add_data error : currentdata < %d pos\n", pos);
			return 0;
		}
		p->currentdata++;
	}
	else {
		printf("add_data �Ҵ� ����\n");
		return 0;
	}
}

int remove_data(DLL *p, int pos) {
	DLN *data_node = NULL;
	DLN *fnode = NULL;
	DLN *anode = NULL;
	data_node = p->headernode;

	if (pos == 0) {
		p->headernode = data_node->pLink;
		p->headernode->fLink = NULL;
	}
	else if (pos < p->currentdata-1) {
		for (int i = 0; i < pos; i++){
			data_node = data_node->pLink;
		}
		fnode = data_node->fLink;
		anode = data_node->pLink;
		
		fnode->pLink = anode;
		anode->fLink = fnode;
	}
	else if (pos == p->currentdata-1) {
		for (int i = 0; i < pos; i++) {
			data_node = data_node->pLink;
		}
		fnode = data_node->fLink;
		fnode->pLink = NULL;
	}
	else {
		printf("remove_data error : currentdata < %d pos", pos);
		return 0;
	}
	p->currentdata--;
}

int delete_data(DLL *p) {
	if (p != NULL) {
		free(p);
	}
	else {
		printf("delete_data : new_list �����Ҵ� ����\n");
		return 0;
	}
}

//��������Ʈ�� ����!

void reverse_Display(DLL *p) {
	DLN *data_node = p->headernode;
	for (int i = 0; i < p->currentdata-1; i++) {
		data_node = data_node->pLink;
	}
	for (int i = p->currentdata-1; i >= 0; i--) {
		printf("reverse : [%d]-%d\n", i, data_node->data);
		data_node = data_node->fLink;
	}
}