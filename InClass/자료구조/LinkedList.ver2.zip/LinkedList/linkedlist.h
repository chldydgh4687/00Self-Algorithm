#pragma once
#ifndef __Linkedlist__
#define __Linkedlist__

typedef struct ListNode {
	int data;
	struct ListNode *pLink;
}LN;

typedef struct LinkedList {
	int currentdata;
	struct ListNode header_node;
}LL;


//1��
LL* create_List();
void Display(LL *pList);
LN *get_node(LL *pList, int pos);
int addLLElement(LL *pList, int pos, LN data);

void remove_element(LL *pList, int pos);
void delete_list(LL *pList);

#endif __Linkedlist__

#ifndef _COMMON_LIST_DEF_
#define _COMMON_LIST_DEF_

#define TRUE 1
#define FALSE 0

#endif

