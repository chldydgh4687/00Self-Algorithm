#pragma once
#ifndef _LINKEDLIST_OP_
#define _LINKEDLIST_OP_

void iterateLinkedList(LL* pList);
void concatLinkedList(LL* pListA, LL* pListB);
void reverseLinkedList(LL* pList);

#endif // !_LINKEDLIST_OP_


