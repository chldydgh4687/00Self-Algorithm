//#pragma once
//#include <stdio.h>
//#include <stdlib.h>
//#include "linkedlist.h"
//#include "linkedlistop.h"
//
//int main()
//{
//	LL *new_list = NULL, *B_list = NULL;
//	LN node;
//
//	new_list = create_List();
//	B_list = create_List();
//	if (new_list != NULL) {
//		node.data = 1;
//		addLLElement(new_list, 0, node);
//
//		node.data = 3;
//		addLLElement(new_list, 1, node);
//
//		node.data = 4;
//		addLLElement(new_list, 2, node);
//
//		node.data = 5;
//		addLLElement(new_list, 3, node);
//
//		node.data = 7;
//		addLLElement(new_list, 4, node);
//		Display(new_list);
//
//		remove_element(new_list, 4, node);
//
//		remove_element(new_list, 1, node);
//		Display(new_list);
//
//		delete_list(new_list);
//	}
//	else {
//		return 0;
//	}
//}


//���� + ��ȸ, ����, Ư�� ���Ḯ��Ʈ�� ��������
#pragma once
#include <stdio.h>
#include <stdlib.h>
#include "linkedlist.h"
#include "linkedlistop.h"

int main()
{
	LL *new_list = NULL, *B_list = NULL;
	LN node;

	new_list = create_List();
	B_list = create_List();
	if (new_list != NULL && B_list != NULL) {
		// new_list
		node.data = 1;
		addLLElement(new_list, 0, node);
		node.data = 2;
		addLLElement(new_list, 1, node);
		node.data = 3;
		addLLElement(new_list, 2, node);

		
		//B_list
		node.data = 4;
		addLLElement(B_list, 0, node);
		node.data = 5;
		addLLElement(B_list, 1, node);
		node.data = 6;
		addLLElement(B_list, 2, node);

		iterateLinkedList(new_list);
		printf("\n");
		iterateLinkedList(B_list);

		//����Ʈ b�� ����Ʈ new_list�� ���̱�
		concatLinkedList(new_list, B_list);
		printf("\n");
		iterateLinkedList(new_list);
		
		//����Ʈ new_list�� �������� �����
		reverseLinkedList(new_list);
		printf("\n");
		iterateLinkedList(new_list);

		delete_list(B_list);
		delete_list(new_list);
	}
	else {
		return 0;
	}
}
