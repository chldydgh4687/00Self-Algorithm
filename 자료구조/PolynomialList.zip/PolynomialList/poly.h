#ifndef _poly_
#define _poly_

int addPolyNodeLast(LL *pList, float coef, int degree);
LL * polyadd(LL *pListA, LL *pListB);
void displayPolyList(LL *pList);

#endif