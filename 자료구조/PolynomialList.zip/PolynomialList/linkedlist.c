#include <stdio.h>
#include <stdlib.h>
#include "linkedlist.h"
#include <string.h>

LL* create_list() {
	LL *new_list = (LL*)malloc(sizeof(LL));
	if (new_list != NULL) {
		memset(new_list,0, sizeof(LL));
		return new_list;
	}
	else {
		printf("create_list : error\n");
		return 0;
	}
}

void delete_list(LL *pList) {
	if (pList != NULL) {
		free(pList);
	}
	else {
		return 0;
	}
}

//void display_list(LL *pList);
//int add_element(LL *pList, int pos, LN data);
//int rm_element(LL *pList, int pos);
