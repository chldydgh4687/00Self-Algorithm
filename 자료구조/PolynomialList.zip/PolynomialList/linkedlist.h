#ifndef __LINKEDLIST_
#define __LINKEDLIST_

typedef struct LinkedNode {
	float coef; //���� ���
	int degree; //���� ����
	struct LinkedNode *pLink;
}LN;

typedef struct LinkedList {
	LN headerNode;
	int currentdata;
}LL;

LL *create_list();
void delete_list(LL *pList);

//void display_list(LL *pList);
//int add_element(LL *pList, int pos, LN data);
//int rm_element(LL *pList, int pos);
//void delete_list(LL *pList);

#endif //__LINKEDLIST_