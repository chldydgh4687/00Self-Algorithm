#include <stdio.h>
#include <stdlib.h>
#include "linkedlist.h"
#include "poly.h"

int main()
{
	LL *A = NULL, *B = NULL;
	LL *C = NULL;
	LN node;

	A = create_list();
	B = create_list();
	
	if (A != NULL && B != NULL) {
		addPolyNodeLast(A, 6, 6);
		addPolyNodeLast(A, 4, 5);
		addPolyNodeLast(A, 2, 2);
		displayPolyList(A);
		printf("\n");

		addPolyNodeLast(B, 1, 5);
		addPolyNodeLast(B, 2, 4);
		addPolyNodeLast(B, 3, 2);
		addPolyNodeLast(B, 4, 0);
		displayPolyList(B);
		printf("\n");

		C = polyadd(A, B);
		displayPolyList(C);

		printf("\n");

		delete_list(A);
		delete_list(B);
	}
	else {
		printf("error\n");
		return 0;
	}
}