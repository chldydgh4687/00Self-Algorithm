#include <stdio.h>
#include <stdlib.h>
#include "linkedlist.h"
#include "poly.h"

int addPolyNodeLast(LL *pList, float coef, int degree) {
	if (pList != NULL) {
		LN *new_node = (LN*)malloc(sizeof(LN));
		LN *fnode = NULL;

		if (new_node != NULL) {
			new_node->coef = coef;
			new_node->degree = degree;
			new_node->pLink = NULL;

			if (pList->currentdata == 0) {
				pList->headerNode.pLink = new_node;
			}
			else {
				fnode = &(pList->headerNode);
				while (fnode->pLink != NULL) {
					fnode = fnode->pLink;
				}
				fnode->pLink = new_node;
			}

			pList->currentdata++;
		}
		else {
			printf("addPoly error\n");
			return 0;
		}
	}
	else {
		printf("list �����Ҵ� ����\n");
		return 0;
	}
}

LL * polyadd(LL *pListA, LL *pListB) {
	LL *alist = pListA;
	LN *target = NULL, *Anode = NULL, *ntarget = NULL;

	target = &(pListB->headerNode);
	Anode = &(alist->headerNode);
	target = target->pLink;
	Anode = Anode->pLink;
	while (target != NULL) {
		while (Anode != NULL) {
			if (Anode->degree == target->degree) {
				Anode->coef = Anode->coef + target->coef;
				target = target->pLink;
				Anode = alist->headerNode.pLink;
				break;
			}
			else {
				//��尡 �ٲ�
				if (target->degree > alist->headerNode.pLink->degree) {
					ntarget = target;
					target = target->pLink;
					ntarget->pLink = Anode;
					pListA->headerNode.pLink = ntarget;
					pListA->currentdata++;
					break;
				}
				if (Anode->pLink == NULL) {
					ntarget = target;
					target = target->pLink;
					Anode->pLink = ntarget;
					ntarget->pLink = NULL;
					pListA->currentdata++;
					break;
				}

				if (Anode->pLink->degree < target->degree) {
					ntarget = target;
					target = target->pLink;
					ntarget->pLink = Anode->pLink;
					Anode->pLink = ntarget;
					pListA->currentdata++;
					Anode = alist->headerNode.pLink;
					break;
				}
			}
			Anode = Anode->pLink;
		}
	}
	return alist;
}

void displayPolyList(LL *pList) {
	if (pList != NULL) {
		LN *f = NULL;
		f = &(pList->headerNode);
		while (1) {
			f = f->pLink;
			printf("%.1f x**%d ", f->coef, f->degree);
			if (f->pLink == NULL)
				break;
			printf("+ ");
		}
	}
	else {
		printf("displayPolyList error\n");
		return 0;
	}
}