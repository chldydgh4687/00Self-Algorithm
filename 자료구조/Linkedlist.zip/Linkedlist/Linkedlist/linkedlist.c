#include <stdio.h>
#include <stdlib.h>
#include "linkedlist.h"

//��ũ�帮��Ʈ ����
LinkedList* createLinkedList(void) {
	LinkedList *p = (LinkedList*)malloc(sizeof(LinkedList));
	if (p != NULL) {
		memset(p, 0, sizeof(LinkedList));
	}
	else {
		printf("error\n");
		return NULL;
	}

	return p;
}

//�ش� ���Ҹ� �����´�.
ListNode* getLLElement(LinkedList *p, int i) {
	
	if (i == 0) {
		return &(p->headerNode);
	}

	ListNode *q = NULL;
	int a;

	q = p->headerNode.pLink;
	for (a = 1; a < i; a++) {
		q = q->pLink;
	}

	return q;
}

//pos �� �����ֱ�
int addLLElement(LinkedList *lp, int pos, ListNode dp) {

	ListNode *p = NULL;
	int i;

	if (lp->currentElementCount == 0 && pos >= 1) {
		printf("currentElementCount = 0\n");
		return 0;
	}
	else if (lp->currentElementCount  < pos) {
		printf("error\n");
		return 0;
	}
	else {//ä���

		if (lp->currentElementCount == 0) {
			lp->headerNode = dp;

			lp->currentElementCount++;
		}
		else if (lp->currentElementCount == pos) {
			if (pos == 1) {
				lp->headerNode.pLink = &dp;
				lp->currentElementCount++;
			}
			else {
				//����Ʈ�� �ּҰ�
				p = lp->headerNode.pLink;
				for (i = 1; i < lp->currentElementCount; i++) {
					p = p->pLink;
				}
				p->pLink = &dp;
			}
		}// ����
	}

}
////�ش� ���Ұ��� �ִ� ���� ����
//int removeLLElement(LinkedList *lp, int d);
////����Ʈ ����
//void deleteLinkedList(LinkedList *lp);

