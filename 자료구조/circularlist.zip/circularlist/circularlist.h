#pragma once
#ifndef __circular__
#define __circular__

typedef struct CircularNode {
	int data;
	struct CirNode *pLink;
}CirNode;

typedef struct CircularList {
	int currentElement;
	struct CirNode *pLink;
}CirList;

CirList *createCirList();
void display(CirList *p);
int addCLElement(CirList *p, int pos, CirNode n);
int removeCLElement(CirList *p, int pos);
void deleteCirList();
int CirCorrect(CirList *p);

#endif