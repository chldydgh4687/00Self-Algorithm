#include <stdio.h>
#include <stdlib.h>
#include "circularlist.h"

int main() {

	CirList *new_List = NULL;
	new_List = createCirList();
	CirNode new_node;
	if (new_List != NULL) {
		
		new_node.data = 1;
		addCLElement(new_List, 0, new_node);

		new_node.data = 3;
		addCLElement(new_List, 1, new_node);
		
		new_node.data = 5;
		addCLElement(new_List, 2, new_node);
		
		new_node.data = 7;
		addCLElement(new_List, 3, new_node);
		//display(new_List);

		removeCLElement(new_List, 3);
		display(new_List);

		deleteCirList(new_List);
	}
	else {
		return 0;
	}
	
}